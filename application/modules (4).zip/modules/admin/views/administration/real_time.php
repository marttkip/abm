<!-- Realtime chart starts -->

<div class="widget boxed">

    <div class="widget-head">
        <h4 class="pull-left"><i class="icon-reorder"></i>Real Time Chart</h4>
        <div class="widget-icons pull-right">
            <a href="#" class="wminimize"><i class="icon-chevron-up"></i></a> 
            <a href="#" class="wclose"><i class="icon-remove"></i></a>
        </div>
        <div class="clearfix"></div>
    </div>             
    
    <div class="widget-content">
        <div class="padd">
        
            <div id="live-chart"></div>
            <hr />
            Time Inverval: <input id="updateInterval" type="text" class="span3" value="">
        
        </div>
    </div>
</div>
