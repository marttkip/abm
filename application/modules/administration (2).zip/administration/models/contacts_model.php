<?php

class Contacts_model extends CI_Model 
{

		/*
	*	Count all items from a table
	*	@param string $table
	* 	@param string $where
	*
	*/
	public function count_items($table, $where, $limit = NULL)
	{
		if($limit != NULL)
		{
			$this->db->limit($limit);
		}
		$this->db->from($table);
		$this->db->where($where);
		return $this->db->count_all_results();
	}

	/*
	*	Retrieve all users
	*	@param string $table
	* 	@param string $where
	*
	*/
	public function get_all_contacts($table, $where, $per_page, $page)
	{
		//retrieve all users
		$this->db->from($table);
		$this->db->select('*');
		$this->db->where($where);
		$this->db->order_by('Firstname', 'ASC');
		$query = $this->db->get('', $per_page, $page);
		
		return $query;
	}


	/*
	*	Import Template
	*
	*/
	function import_template()
	{
		$this->load->library('Excel');
		
		$title = 'Contacts Import Template';
		$count=1;
		$row_count=0;
		
		$report[$row_count][0] = 'Last Name';
		$report[$row_count][1] = 'First name';
		$report[$row_count][2] = 'Middle name';
		$report[$row_count][3] = 'Gender';

		$report[$row_count][4] = 'Birth Date';
		$report[$row_count][5] = 'Phone number';
		$report[$row_count][6] = 'Literate status';
		$report[$row_count][7] = 'Email';

		$report[$row_count][8] = 'Registrationdate';
		$report[$row_count][9] = 'Applicationnumber';
		$report[$row_count][10] = 'IDtype';
		$report[$row_count][11] = 'IDnumber';

		$report[$row_count][12] = 'IDserialnumber';
		$report[$row_count][13] = 'Countycode';
		$report[$row_count][14] = 'Countyname';
		$report[$row_count][15] = 'Constituencycode';


		$report[$row_count][16] = 'Constituencyname';
		$report[$row_count][17] = 'CAWcode';
		$report[$row_count][18] = 'CAWname';
		$report[$row_count][19] = 'Pollingstationcode';

		$report[$row_count][20] = 'Pollingstationname';
		$report[$row_count][21] = 'Streamcode';

	
		
		$row_count++;
		
		//create the excel document
		$this->excel->addArray ( $report );
		$this->excel->generateXML ($title);
	}

	public function import_csv_charges($upload_path, $service_id)
	{
		//load the file model
		$this->load->model('admin/file_model');
		/*
			-----------------------------------------------------------------------------------------
			Upload csv
			-----------------------------------------------------------------------------------------
		*/
		$response = $this->file_model->upload_csv($upload_path, 'import_csv');
		
		if($response['check'])
		{
			$file_name = $response['file_name'];
			
			$array = $this->file_model->get_array_from_csv($upload_path.'/'.$file_name);
			// var_dump($array); die();
			$response2 = $this->sort_csv_charges_data($array, $service_id);
		
			if($this->file_model->delete_file($upload_path."\\".$file_name, $upload_path))
			{
			}
			
			return $response2;
		}
		
		else
		{
			$this->session->set_userdata('error_message', $response['error']);
			return FALSE;
		}
	}
	public function sort_csv_charges_data($array, $message_category_id)
	{
		//count total rows
		$total_rows = count($array);
		$total_columns = count($array[0]);
		// var_dump($total_columns); die();
		
		//if products exist in array
		if(($total_rows > 0) && ($total_columns == 22))
		{
			$count = 0;
			$comment = '';
			// $items['modified_by'] = $this->session->userdata('personnel_id');
			
			//retrieve the data from array
			for($r = 1; $r < $total_rows; $r++)
			{
				$service_charge_insert['Lastname'] = ucwords(strtolower($array[$r][0]));
				$service_charge_insert['Firstname'] = ucwords(strtolower($array[$r][1]));
				$service_charge_insert['Middlename'] = ucwords(strtolower($array[$r][2]));
				$service_charge_insert['Gender'] = $array[$r][3];
				$birthDate = $array[$r][4];

				$service_charge_insert['Phonenumber'] = $array[$r][5];
				$service_charge_insert['Literatestatus'] = $array[$r][6];
				$service_charge_insert['Email'] = $array[$r][7];
				$service_charge_insert['Registrationdate'] = $array[$r][8];

				$service_charge_insert['Applicationnumber'] = $array[$r][9];
				$service_charge_insert['IDtype'] = $array[$r][10];
				$service_charge_insert['IDnumber'] = $array[$r][11];
				$service_charge_insert['IDserialnumber'] = $array[$r][12];

				$service_charge_insert['Countycode'] = $array[$r][13];
				$service_charge_insert['Countyname'] = $array[$r][14];
				$service_charge_insert['Constituencycode'] = $array[$r][15];
				$service_charge_insert['Constituencyname'] = $array[$r][16];

				$service_charge_insert['CAWcode'] = $array[$r][17];
				$service_charge_insert['CAWname'] = $array[$r][18];
				$service_charge_insert['Pollingstationcode'] = $array[$r][19];
				$service_charge_insert['Pollingstationname'] = $array[$r][20];
				$service_charge_insert['Streamcode'] = $array[$r][21];
				$date = str_replace('/', '-', $birthDate);
				$birthDate =  date('Y-m-d', strtotime($date));
				$from = new DateTime($birthDate);
				$to   = new DateTime('today');
				$from->diff($to)->y;

				# procedural
				$age = date_diff(date_create($birthDate), date_create('today'))->y;
				$service_charge_insert['age'] = $age;
				$service_charge_insert['Birthdate'] = $birthDate;
	
				$count++;
				
				if(empty($service_charge_insert['Phonenumber']))
				{

				}else
				{
					if($this->db->insert('allcounties', $service_charge_insert))
					{
						$comment .= '<br/>Details successfully added to the database';
						$class = 'success';
					}
					
					else
					{
						$comment .= '<br/>Not saved internal error';
						$class = 'danger';
					}
				}
		
				
				
			}	
			$return['response'] = TRUE;
			$return['check'] = TRUE;
				
		}
		else
		{
			$return['response'] = FALSE;
			$return['check'] = FALSE;
		}
		
		return $return;
	}
	public function delete_contact($contact_id)
	{
		$this->db->where('entryid', $contact_id);
		
		if($this->db->delete('allcounties'))
		{
			return TRUE;
		}
		
		else
		{
			return FALSE;
		}
	}

}

?>